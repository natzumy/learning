//                  
// 	ClearBox French Language File (JavaScript)
//

var

	CB_NavTextPrv='précédent',				                    // texte pour image précédente
	CB_NavTextNxt='suivant',					                // texte pour image suivante
	CB_NavTextFull='plein écran',				                // texte pour l'image originale (uniquement pour les images)
	CB_NavTextOpen='ouvrir dans une nouvelle fenętre',		    // texte pour ouvrir dans une nouvelle fenętre
	CB_NavTextDL='télécharger',				                    // texte pour télécharger une image ou un autre contenu
	CB_NavTextClose='fermer',			                        // texte pour fermer clearbox
	CB_NavTextStart='démarrer le diaporama',			        // texte pour démarrer le diaporama
	CB_NavTextStop='arręter le diaporama',			            // texte pour arręter le diaporama
	CB_NavTextRotR='rotation de l\'image ŕ 90° vers la droite',	// texte pour faire une rotation vers la droite
	CB_NavTextRotL='rotation de l\'image ŕ 90° vers la gauche',	// texte pour faire une rotation vers la gauche
	CB_NavTextReady='clearbox is ready'				// text of clearbox ready

;