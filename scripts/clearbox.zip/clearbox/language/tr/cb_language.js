//                  
// 	ClearBox Language File (JavaScript)
//

var

	CB_NavTextPrv='Önceki',						// text of previous image
	CB_NavTextNxt='Sonraki',					// text of next image
	CB_NavTextFull='Gerçek Boyut',					// text of original size (only at pictures)
	CB_NavTextOpen='Ýçeriđi Yeni Pencerede Aç',			// text of open in a new browser window
	CB_NavTextDL='Ýçeriđi Yeni Pencerede Aç / Kaydet',		// text of download picture or any other content
	CB_NavTextClose='ClearBoxu Kapat',				// text of close CB
	CB_NavTextStart='Slideshow Baţlat',				// text of start slideshow
	CB_NavTextStop='Slideshow Durdur',				// text of stop slideshow
	CB_NavTextRotR='Resmi 90 Derece Sađa Çevir',			// text of rotation right
	CB_NavTextRotL='Resmi 90 Derece Sola Çevir',			// text of rotation left
	CB_NavTextReady='clearbox is ready'				// text of clearbox ready

;