//                  
// 	ClearBox Language File (JavaScript)
//

var

	CB_NavTextPrv='předchozí',				// text of previous image
	CB_NavTextNxt='další',					// text of next image
	CB_NavTextFull='plná velikost',				// text of original size (only at pictures)
	CB_NavTextOpen='zobrazit v novém okně prohlížeče',		// text of open in a new browser window
	CB_NavTextDL='stáhnout',				// text of download picture or any other content
	CB_NavTextClose='zavřít',			// text of close CB
	CB_NavTextStart='spustit prezentaci',			// text of start slideshow
	CB_NavTextStop='zastavit prezentaci',			// text of stop slideshow
	CB_NavTextRotR='otočit obrázek o 90 stupnů doprava',	// text of rotation right
	CB_NavTextRotL='otočit obrázek o 90 stupnů doleva'	// text of rotation left
	CB_NavTextReady='clearbox is ready'		// text of clearbox ready

;