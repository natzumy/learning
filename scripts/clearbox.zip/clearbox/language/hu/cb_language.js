//                  
// 	ClearBox Language File (JavaScript)
//

var

	CB_NavTextPrv='előző',					// text of previous image
	CB_NavTextNxt='következő',				// text of next image
	CB_NavTextFull='teljes méretű kép megtekintése',	// text of original size (only at pictures)
	CB_NavTextOpen='megnyitás a böngészőben',		// text of open content in a new browser window
	CB_NavTextDL='letöltés',				// text of download picture or any other content
	CB_NavTextClose='clearbox ablak bezárása',		// text of close CB
	CB_NavTextStart='slideshow elindítása',			// text of start slideshow
	CB_NavTextStop='slideshow megállítása',			// text of stop slideshow
	CB_NavTextRotR='kép elforgatása jobbra 90 fokkal',	// text of rotation right
	CB_NavTextRotL='kép elforgatása balra 90 fokkal',	// text of rotation left
	CB_NavTextReady='a clearbox betöltődött'		// text of clearbox ready

;